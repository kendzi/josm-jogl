#! /bin/bash

gcc -o alignment_test alignment_test.c
./alignment_test
