#define inttest0  100
#define inttest1 -100

#define longtest0  10000000000
#define longtest1 -10000000000

#define floattest0  100.0
#define floattest1 -100.0
#define floattest2  0.01
#define floattest3 -0.01
#define floattest4  1e2
#define floattest5 -1e2
#define floattest6  1e-2
#define floattest7 -1e-2

#define doubletest0  2e150
#define doubletest1 -2e150
#define doubletest2  2e-150
#define doubletest3 -2e-150
