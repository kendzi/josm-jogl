adb $* install ../build-android-armv7/jogamp-android-launcher.apk
adb $* install ../build-android-armv7/gluegen-rt-android-armeabi-v7a.apk
