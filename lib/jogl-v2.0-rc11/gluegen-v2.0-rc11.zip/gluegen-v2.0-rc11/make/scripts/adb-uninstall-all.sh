adb $* uninstall jogamp.android.launcher
adb $* uninstall com.jogamp.common
