adb $* install ../build-android-armv6/jogamp-android-launcher.apk
adb $* install ../build-android-armv6/gluegen-rt-android-armeabi.apk
