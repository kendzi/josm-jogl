#ifndef __gluegen_stddef_h
#define __gluegen_stddef_h

#include <gluegen_types.h>

#endif /* __gluegen_stddef_h */
