#ifndef __gluegen_stdint_h
#define __gluegen_stdint_h

#include <gluegen_types.h>

#endif /* __gluegen_stdint_h */

