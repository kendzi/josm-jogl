scripts/make.jogl.all.linux-x86_64.sh -Dtestclass=com.jogamp.opengl.test.junit.jogl.acore.TestSharedContextListAWT -f build-test.xml junit.run.awt.singletest
