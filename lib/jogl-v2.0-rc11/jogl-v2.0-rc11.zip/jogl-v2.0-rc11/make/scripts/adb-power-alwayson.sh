sdir=`dirname $0`

adb $* shell svc power stayon true
