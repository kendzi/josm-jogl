#! /bin/bash

rm -rf ../build/test/* \
       ../build/jar/jogl.test.jar

