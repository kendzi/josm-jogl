#adb $* install ../../gluegen/build-android-armv6/jogamp-android-launcher.apk
#adb $* install ../../gluegen/build-android-armv6/gluegen-rt-android-armeabi.apk
adb $* install ../build-android-armv6/jar/jogl-all-android-armeabi.apk
adb $* install ../build-android-armv6/jar/jogl-test-android.apk
