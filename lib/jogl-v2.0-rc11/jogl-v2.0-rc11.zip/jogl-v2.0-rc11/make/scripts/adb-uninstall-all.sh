#adb $* uninstall jogamp.android.launcher
#adb $* uninstall com.jogamp.common
adb $* uninstall javax.media.opengl
adb $* uninstall com.jogamp.opengl.test
