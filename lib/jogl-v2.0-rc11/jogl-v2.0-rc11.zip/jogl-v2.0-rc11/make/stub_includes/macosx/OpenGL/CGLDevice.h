typedef struct _cglShareGroupObj*  CGLShareGroupObj;

