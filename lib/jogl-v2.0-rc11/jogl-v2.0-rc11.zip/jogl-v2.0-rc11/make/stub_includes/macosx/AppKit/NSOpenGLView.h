typedef struct _NSOpenGLView NSOpenGLView;
