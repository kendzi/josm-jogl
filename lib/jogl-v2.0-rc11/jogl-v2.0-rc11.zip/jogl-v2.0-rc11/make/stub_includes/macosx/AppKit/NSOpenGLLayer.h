typedef struct _NSOpenGLLayer NSOpenGLLayer;
